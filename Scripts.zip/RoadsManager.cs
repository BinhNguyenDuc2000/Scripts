using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoadsManager : MonoBehaviour
{
    // Agent 
    [SerializeField] private CarControllerAgent carControllerAgent;

    private List<Road> roadList;
    private int nextRoad;

    private int numberOfRuns;
    private int numberOfCrashes;
    [SerializeField] private int maxNumberOfRuns;

    private void Awake()
    {
        nextRoad = 0;
        roadList = new List<Road>(); 
        foreach (Road road in GetComponentsInChildren<Road>())
        {
            road.SetRoadsManager(this);
            roadList.Add(road);
        }
        numberOfRuns = 0;
        numberOfCrashes = 0;
    }

    private void OnApplicationQuit()
    {
        Debug.Log("Total number of runs: " + numberOfRuns);
        Debug.Log("Total number of crashes: " + numberOfCrashes);
    }

    // Events
    public void AgentWentThrough(Road road, float x)
    {
        if (roadList.IndexOf(road) == roadList.Count - 2)
        {
            carControllerAgent.onAgentCorrectLastRoad();
            ResetRoadsManager();
        }

        if (roadList.IndexOf(road) == nextRoad)
        {
            carControllerAgent.onAgentCorrectRoad();
            nextRoad = (roadList.IndexOf(road) + 1) % roadList.Count;
        }
    }

    public void Crash()
    {
        if (numberOfRuns < maxNumberOfRuns)
            numberOfCrashes++;
        ResetRoadsManager();
    }

    // Not needed
    public void RuleBasedCarWentThrough(Road road, Transform car)
    {
    }

    public void ResetRoadsManager()
    {
        nextRoad = 0;
        // if (numberOfRuns < maxNumberOfRuns)
        // {
        //     numberOfRuns++;
        //     Debug.Log("Total number of runs: " + numberOfRuns);
        //     Debug.Log("Total number of crashes: " + numberOfCrashes);
        // }
    }

    public Road GetNextCheckpoint()
    {
        return roadList[nextRoad];
    }

    private void FixedUpdate()
    {
    }
}


